﻿using System;
using System.IO;
using System.Windows.Forms;
using static newgym.Supplements;

namespace newgym
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        { 

            string enteredusername = textBox1.Text.Trim();
            string password = textBox2.Text.Trim();
            string filePath = "storecredentials.txt";

            PackageData.Username = enteredusername;

            if (string.IsNullOrWhiteSpace(enteredusername) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Please enter both username and password.", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!File.Exists(filePath))
            {
                MessageBox.Show("No users found. Please sign up first.", "File Not Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string[] users = File.ReadAllLines(filePath);
            bool userFound = false;

            foreach (string line in users)
            {
                string[] parts = line.Split(',');

                if (parts.Length >= 5)
                {
                    string storedUsername = parts[0];
                    string storedPassword = parts[3];

                    if (storedUsername == enteredusername && storedPassword == password)
                    {
                        userFound = true;
                        MessageBox.Show("Login successful!", "Welcome", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        this.Hide();
                         new Dashboard().Show(); 
                        break;
                    }
                }
            }

            if (!userFound)
            {
                MessageBox.Show("Incorrect username or password.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SignUpForm signUpForm = new SignUpForm();
            signUpForm.Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
