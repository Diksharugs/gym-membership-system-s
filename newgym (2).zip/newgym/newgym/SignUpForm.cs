﻿using System;
using System.IO;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace newgym
{
    public partial class SignUpForm : Form
    {
         string filePath = "storecredentials.txt"; // Data file

        public SignUpForm()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text.Trim();
            DateTime dob = dateTimePicker1.Value;
            string profession = textBox2.Text.Trim().ToLower();
            string password = textBox3.Text;

            // Validate inputs
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(profession) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Please fill in all fields.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (password.Length < 8)
            {
                MessageBox.Show("Password must be at least 8 characters long.", "Password Too Short", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Check if user already exists
            if (File.Exists(filePath))
            {
                string[] users = File.ReadAllLines(filePath);
                foreach (var user in users)
                {
                    if (user.StartsWith(username + ","))
                    {
                        MessageBox.Show("Username already exists. Please choose another.", "Duplicate Username", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }
            }

           
            decimal discount = profession.Contains("student") ? 10.0m : 0.0m;

           
            string userData = $"{username},{dob.ToShortDateString()},{profession},{password},{discount}%";
            File.AppendAllText(filePath, userData + Environment.NewLine);

            MessageBox.Show("Sign up successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            
            this.Hide();
            Form1 loginForm = new Form1();
            loginForm.Show();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Form1 loginForm = new Form1();
            loginForm.Show();
        }

        // Other optional event handlers
        private void label2_Click(object sender, EventArgs e) { }
        private void textBox1_TextChanged(object sender, EventArgs e) { }
        private void dateTimePicker1_ValueChanged(object sender, EventArgs e) { }
        private void textBox2_TextChanged(object sender, EventArgs e) { }
        private void textBox3_TextChanged(object sender, EventArgs e) { }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
