﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using static newgym.Supplements;

namespace newgym
{
    public partial class Checkout : Form
    {
        public Checkout()
        {
            InitializeComponent();
            this.Load += new EventHandler(Checkout_Load);
        }

        private void Checkout_Load(object sender, EventArgs e)
        {
           
            label2.Text = "Username: " + PackageData.Username;

           
            label3.Text = "Date: " + DateTime.Now.ToString("dd/MM/yyyy hh:mm tt");

            
            listBox1.Items.Clear();

            if (PackageData.SelectedSupplements.Count > 0)
            {
                foreach (string item in PackageData.SelectedSupplements)
                {
                    listBox1.Items.Add(item);
                }
            }
            else
            {
                listBox1.Items.Add("No supplements selected.");
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void label3_Click(object sender, EventArgs e)
        {
            
        }
        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Thank you! Your package has been confirmed.", "Checkout complete", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            
        }
    }
}
