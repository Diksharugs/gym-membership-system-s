﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace newgym
{
    public partial class Supplements: Form
    {
        public static class PackageData
        {
            public static string Username { get; set; }
            public static List<string> SelectedSupplements { get; set; } = new List<string>();
        }

        public Supplements()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            PackageData.SelectedSupplements.Add("Whey protein shakes");
            MessageBox.Show("Supplement added to package", "success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Dashboard dashboard = new Dashboard();
            dashboard.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            PackageData.SelectedSupplements.Add("2.5g creatine powder shakes");
            MessageBox.Show("Supplement added to package", "success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            PackageData.SelectedSupplements.Add("22g Mass gainer mix shakes");
            MessageBox.Show("Supplement added to package", "success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Checkout checkout = new Checkout();
            checkout.Show();
            this.Hide();
        }
    }
}
